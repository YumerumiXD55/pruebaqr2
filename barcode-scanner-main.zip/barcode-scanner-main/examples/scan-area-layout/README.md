This example is meant to demonstrate how you can use HTML/CSS to design a layout for the scan area.

Below you can find a picture of the final result:

<img height="450" src="./result.png" alt="capacitor-barcode-scanner layout example result">
